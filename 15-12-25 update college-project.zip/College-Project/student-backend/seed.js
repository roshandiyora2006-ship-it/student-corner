const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const Student = require('./models/student');
const Teacher = require('./models/teacher');

const MONGO_URI = 'mongodb://127.0.0.1:27017/studentdb';

async function seed() {
  await mongoose.connect(MONGO_URI);

  // Clear existing
  await Student.deleteMany({});
  await Teacher.deleteMany({});

  // Create teacher
  const teacher = new Teacher({
    name: 'Test Teacher',
    email: 'teacher@test.com',
    password: await bcrypt.hash('teacher123', 10),
  });
  await teacher.save();

  // Create sample students across courses/divisions/semesters
  const studentsData = [
    {
      name: 'Alice BBA A1',
      dob: '2006-02-10',
      email: 'alice.bba.a1@test.com',
      course: 'BBA',
      phone: '1234567890',
      address: '12 King St',
      semester: 'SEM-1',
      division: 'A',
      subjects: [
        { name: 'Management', marks: 82 },
        { name: 'Accounting', marks: 76 },
      ],
    },
    {
      name: 'Bob BBA A2',
      dob: '2006-05-20',
      email: 'bob.bba.a2@test.com',
      course: 'BBA',
      phone: '1234509876',
      address: '34 Queen St',
      semester: 'SEM-2',
      division: 'A',
      subjects: [
        { name: 'Economics', marks: 88 },
        { name: 'Marketing', marks: 79 },
      ],
    },
    {
      name: 'Cara BBA B1',
      dob: '2005-12-01',
      email: 'cara.bba.b1@test.com',
      course: 'BBA',
      phone: '9998887776',
      address: '56 Lake Rd',
      semester: 'SEM-1',
      division: 'B',
      subjects: [
        { name: 'Finance', marks: 91 },
        { name: 'HR', marks: 84 },
      ],
    },
    {
      name: 'Dan BCA A1',
      dob: '2006-03-15',
      email: 'dan.bca.a1@test.com',
      course: 'BCA',
      phone: '8887776665',
      address: '78 Hill Ave',
      semester: 'SEM-1',
      division: 'A',
      subjects: [
        { name: 'Programming', marks: 92 },
        { name: 'Data Structures', marks: 86 },
      ],
    },
    {
      name: 'Eva BCA B1',
      dob: '2006-07-30',
      email: 'eva.bca.b1@test.com',
      course: 'BCA',
      phone: '7776665554',
      address: '90 River Rd',
      semester: 'SEM-2',
      division: 'B',
      subjects: [
        { name: 'Databases', marks: 80 },
        { name: 'Networks', marks: 74 },
      ],
    },
    {
      name: 'Fred BCOM A1',
      dob: '2005-11-11',
      email: 'fred.bcom.a1@test.com',
      course: 'BCOM',
      phone: '6665554443',
      address: '21 Park Ln',
      semester: 'SEM-3',
      division: 'A',
      subjects: [
        { name: 'Taxation', marks: 85 },
        { name: 'Auditing', marks: 78 },
      ],
    },
    {
      name: 'Gina B.ED A1',
      dob: '2005-09-09',
      email: 'gina.bed.a1@test.com',
      course: 'B.ED',
      phone: '5554443332',
      address: '43 Sunset Blvd',
      semester: 'SEM-1',
      division: 'A',
      subjects: [
        { name: 'Pedagogy', marks: 87 },
        { name: 'Psychology', marks: 90 },
      ],
    },
    {
      name: 'Henry B.ED B1',
      dob: '2006-04-04',
      email: 'henry.bed.b1@test.com',
      course: 'B.ED',
      phone: '4443332221',
      address: '65 Sunrise Ave',
      semester: 'SEM-2',
      division: 'B',
      subjects: [
        { name: 'Curriculum', marks: 83 },
        { name: 'Assessment', marks: 77 },
      ],
    },
  ];

  const studentPassword = await bcrypt.hash('student123', 10);
  const students = await Student.insertMany(
    studentsData.map((s) => ({
      ...s,
      password: studentPassword,
    }))
  );

  console.log(`Seeded teacher and ${students.length} students!`);
  mongoose.disconnect();
}

seed();
