const mongoose = require("mongoose");

// Define Student schema
const studentSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  dob: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
  },
  course: {
    type: String,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  phone: {
    type: String,
    required: true,
  },
  address: {
    type: String,
    required: true,
  },
  semester: {
    type: String,
    required: true,
  },
  division: {
    type: String,
    required: true,
  },
  subjects: [
    {
      name: { type: String, required: true },
      marks: { type: Number, required: true }
    }
  ],
  role: {
    type: String,
    default: 'student',
  },
});

// Create model
const Student = mongoose.model("Student", studentSchema);

module.exports = Student;
