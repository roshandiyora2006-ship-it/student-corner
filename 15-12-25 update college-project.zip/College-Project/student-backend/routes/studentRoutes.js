
const express = require("express");
const { authMiddleware } = require("./auth");
const Student = require("../models/student.js");
const router = express.Router();

// ✅ Student: View own profile and marks
router.get("/me", authMiddleware(["student"]), async (req, res) => {
  try {
    const student = await Student.findById(req.user.id);
    if (!student) return res.status(404).json({ message: "Student not found" });
    res.json(student);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Student: update own profile
router.put("/me", authMiddleware(["student"]), async (req, res) => {
  try {
    console.log('Update request for student:', req.user.id);
    console.log('Payload received:', req.body);
    
    const update = { ...req.body };
    // Prevent role changes or other protected fields
    delete update.role;
    delete update._id;
    delete update.subjects; // prevent subjects modification through this endpoint
    
    // If password provided, hash it
    if (update.password) {
      const bcrypt = require('bcryptjs');
      update.password = await bcrypt.hash(update.password, 10);
    }
    
    console.log('Applying update:', update);
    const student = await Student.findByIdAndUpdate(req.user.id, update, { new: true, runValidators: true });
    
    if (!student) return res.status(404).json({ message: "Student not found" });
    
    console.log('Update successful:', student);
    res.json(student);
  } catch (error) {
    console.error('Update error:', error);
    res.status(400).json({ message: error.message });
  }
});

// ✅ Teacher: Add new student (with all fields, hash password)
const bcrypt = require('bcryptjs');
router.post("/", authMiddleware(["teacher"]), async (req, res) => {
  try {
    const { password, ...rest } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const student = new Student({ ...rest, password: hashedPassword });
    await student.save();
    res.status(201).json(student);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// ✅ Teacher: Assign/Update marks for a student (by subject)
router.put("/:id/marks", authMiddleware(["teacher"]), async (req, res) => {
  try {
    const { subjects } = req.body; // subjects: [{ name, marks }]
    const student = await Student.findByIdAndUpdate(
      req.params.id,
      { subjects },
      { new: true }
    );
    if (!student) return res.status(404).json({ message: "Student not found" });
    res.json(student);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// ✅ Teacher: Get all students
router.get("/", authMiddleware(["teacher"]), async (req, res) => {
  try {
    const students = await Student.find();
    res.json(students);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// (Optional) Teacher: Update student by ID
router.put("/:id", authMiddleware(["teacher"]), async (req, res) => {
  try {
    const student = await Student.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!student) return res.status(404).json({ message: "Student not found" });
    res.json(student);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// (Optional) Teacher: Delete student by ID
router.delete("/:id", authMiddleware(["teacher"]), async (req, res) => {
  try {
    const student = await Student.findByIdAndDelete(req.params.id);
    if (!student) return res.status(404).json({ message: "Student not found" });
    res.json({ message: "Student deleted" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
