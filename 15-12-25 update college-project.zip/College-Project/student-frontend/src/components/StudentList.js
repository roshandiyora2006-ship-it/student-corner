import React from "react";
import "./StudentList.css";



import  { useState } from "react";
import "./StudentList.css";

function StudentList({ students, handleEdit, handleDelete }) {
  const [selected, setSelected] = useState(null);

  return (
    <div>
      <table className="student-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>DOB</th>
            <th>Phone</th>
            <th>Address</th>
            <th>Semester</th>
            <th>Division</th>
            <th>Course</th>
            <th>Subjects & Marks</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {students.map((s) => (
            <tr key={s._id}>
              <td>{s.name}</td>
              <td>{s.email}</td>
              <td>{s.dob}</td>
              <td>{s.phone}</td>
              <td>{s.address}</td>
              <td>{s.semester}</td>
              <td>{s.division}</td>
              <td>{s.course}</td>
              <td>
                <ul style={{margin:0, paddingLeft:16}}>
                  {s.subjects && s.subjects.length > 0 ? (
                    s.subjects.map((subj, idx) => (
                      <li key={idx}>{subj.name}: {subj.marks}</li>
                    ))
                  ) : (
                    <li>No subjects</li>
                  )}
                </ul>
              </td>
              <td>
                <button onClick={() => handleEdit(s)}>Edit</button>
                <button onClick={() => handleDelete(s._id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default StudentList;






