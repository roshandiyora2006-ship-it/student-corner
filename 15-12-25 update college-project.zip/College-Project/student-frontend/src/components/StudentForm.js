import React, { useState } from "react";
import {
  FaUser,
  FaEnvelope,
  FaPhone,
  FaMapMarkerAlt,
  FaGraduationCap,
  FaKey,
  FaPlus,
  FaMinus,
  FaBook,
  FaExclamationTriangle,
} from "react-icons/fa";
import "./StudentForm.css";

function StudentForm({
  form,
  setForm,
  handleSubmit,
  editingId,
  handleCancelEdit,
}) {
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});

  // Validation functions
  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const validatePhone = (phone) => {
    const phoneRegex = /^[0-9]{10}$/;
    return phoneRegex.test(phone);
  };

  const validateName = (name) => {
    const nameRegex = /^[a-zA-Z\s]+$/;
    return (
      nameRegex.test(name.trim()) &&
      name.trim().length >= 2 &&
      name.trim().length <= 50
    );
  };

  const validateDob = (dob) => {
    return Boolean(Date.parse(dob));
  };

  const validatePassword = (password) => {
    return password.length >= 6;
  };

  const validateSubjectMarks = (marks) => {
    // Check if marks contain only digits
    const digitRegex = /^[0-9]+$/;
    if (!digitRegex.test(marks)) return false;

    const marksNum = parseInt(marks);
    return marksNum >= 0 && marksNum <= 100;
  };

  // Real-time validation
  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });

    // Validate field in real-time
    let fieldError = "";

    switch (name) {
      case "name":
        if (value && !validateName(value)) {
          fieldError =
            "Name must contain only alphabets and spaces (2-50 characters)";
        }
        break;
      case "email":
        if (value && !validateEmail(value)) {
          fieldError = "Please enter a valid email address";
        }
        break;
      case "phone":
        if (value && !validatePhone(value)) {
          fieldError = "Phone number must be exactly 10 digits";
        }
        break;
      case "dob":
        if (value && !validateDob(value)) {
          fieldError = "Please enter a valid date";
        }
        break;
      case "password":
        if (value && !validatePassword(value)) {
          fieldError = "Password must be at least 6 characters long";
        }
        break;
      default:
        break;
    }

    setErrors({ ...errors, [name]: fieldError });
    setTouched({ ...touched, [name]: true });
  };

  // For subjects/marks with validation
  const handleSubjectChange = (idx, field, value) => {
    const newSubjects = form.subjects.map((subj, i) =>
      i === idx ? { ...subj, [field]: value } : subj
    );
    setForm({ ...form, subjects: newSubjects });

    // Validate marks
    if (field === "marks") {
      let fieldError = "";
      if (value && !validateSubjectMarks(value)) {
        // Check if it contains non-digits first
        const digitRegex = /^[0-9]+$/;
        if (!digitRegex.test(value)) {
          fieldError = "Marks must contain only digits (numbers)";
        } else {
          fieldError = "Marks must be between 0 and 100";
        }
      }
      setErrors({ ...errors, [`subject_${idx}_marks`]: fieldError });
    }

    // Validate subject name
    if (field === "name") {
      let fieldError = "";
      if (value && value.trim().length < 2) {
        fieldError = "Subject name must be at least 2 characters";
      }
      setErrors({ ...errors, [`subject_${idx}_name`]: fieldError });
    }
  };

  const addSubject = () => {
    setForm({ ...form, subjects: [...form.subjects, { name: "", marks: "" }] });
  };

  const removeSubject = (idx) => {
    setForm({ ...form, subjects: form.subjects.filter((_, i) => i !== idx) });
    // Clean up errors for removed subject
    const newErrors = { ...errors };
    delete newErrors[`subject_${idx}_marks`];
    delete newErrors[`subject_${idx}_name`];
    setErrors(newErrors);
  };

  // Form submission validation
  const handleFormSubmit = (e) => {
    e.preventDefault();

    // Validate all fields
    const newErrors = {};

    // Required field validations
    if (!form.name.trim()) newErrors.name = "Name is required";
    else if (!validateName(form.name)) {
      const nameRegex = /^[a-zA-Z\s]+$/;
      if (!nameRegex.test(form.name.trim())) {
        newErrors.name = "Name must contain only alphabets and spaces";
      } else {
        newErrors.name = "Name must be 2-50 characters";
      }
    }

    if (!form.email.trim()) newErrors.email = "Email is required";
    else if (!validateEmail(form.email))
      newErrors.email = "Please enter a valid email address";

    if (!form.phone.trim()) newErrors.phone = "Phone number is required";
    else if (!validatePhone(form.phone))
      newErrors.phone = "Phone number must be exactly 10 digits";

    if (!form.dob) newErrors.dob = "Date of birth is required";
    else if (!validateDob(form.dob)) newErrors.dob = "Please enter a valid date";

    if (!form.course.trim()) newErrors.course = "Course is required";
    if (!form.semester.trim()) newErrors.semester = "Semester is required";
    if (!form.division.trim()) newErrors.division = "Division is required";
    if (!form.address.trim()) newErrors.address = "Address is required";

    if (!editingId) {
      if (!form.password.trim()) newErrors.password = "Password is required";
      else if (!validatePassword(form.password))
        newErrors.password = "Password must be at least 6 characters long";
    }

    // Validate subjects
    form.subjects.forEach((subj, idx) => {
      if (!subj.name.trim()) {
        newErrors[`subject_${idx}_name`] = "Subject name is required";
      }
      if (!subj.marks) {
        newErrors[`subject_${idx}_marks`] = "Marks are required";
      } else if (!validateSubjectMarks(subj.marks)) {
        const digitRegex = /^[0-9]+$/;
        if (!digitRegex.test(subj.marks)) {
          newErrors[`subject_${idx}_marks`] =
            "Marks must contain only digits (numbers)";
        } else {
          newErrors[`subject_${idx}_marks`] = "Marks must be between 0 and 100";
        }
      }
    });

    setErrors(newErrors);
    setTouched(
      Object.keys(form).reduce((acc, key) => ({ ...acc, [key]: true }), {})
    );

    // If no errors, submit the form
    if (Object.keys(newErrors).length === 0) {
      handleSubmit(e);
    }
  };

  return (
    <div className="form-container">
      <div className="form-header">
        <h2>{editingId ? "Edit Student" : "Add New Student"}</h2>
        <p>
          {editingId
            ? "Update student information below"
            : "Fill in the student details to add them to the system"}
        </p>
      </div>

      <form onSubmit={handleFormSubmit} className="student-form">
        <div className="form-grid">
          {/* Personal Information */}
          <div className="form-section">
            <h3>
              <FaUser className="section-icon" /> Personal Information
            </h3>

            <div className="input-group">
              <label htmlFor="name">Full Name *</label>
              <input
                type="text"
                id="name"
                name="name"
                placeholder="Enter student's full name"
                value={form.name}
                onChange={handleChange}
                className={errors.name && touched.name ? "error" : ""}
                required
              />
              {errors.name && touched.name && (
                <div className="error-message">
                  <FaExclamationTriangle className="error-icon" />
                  {errors.name}
                </div>
              )}
            </div>

            <div className="input-group">
              <label htmlFor="dob">Date of Birth *</label>
              <input
                type="date"
                id="dob"
                name="dob"
                value={form.dob}
                onChange={handleChange}
                className={errors.dob && touched.dob ? "error" : ""}
                required
              />
              {errors.dob && touched.dob && (
                <div className="error-message">
                  <FaExclamationTriangle className="error-icon" />
                  {errors.dob}
                </div>
              )}
            </div>

            <div className="input-group">
              <label htmlFor="email">Email Address *</label>
              <input
                type="email"
                id="email"
                name="email"
                placeholder="student@example.com"
                value={form.email}
                onChange={handleChange}
                className={errors.email && touched.email ? "error" : ""}
                required
              />
              {errors.email && touched.email && (
                <div className="error-message">
                  <FaExclamationTriangle className="error-icon" />
                  {errors.email}
                </div>
              )}
            </div>

            <div className="input-group">
              <label htmlFor="phone">Phone Number *</label>
              <input
                type="tel"
                id="phone"
                name="phone"
                placeholder="Enter 10-digit phone number"
                value={form.phone}
                onChange={(e) => {
                  // Remove non-digit characters
                  const value = e.target.value.replace(/\D/g, "");
                  handleChange({ target: { name: "phone", value } });
                }}
                maxLength="10"
                className={errors.phone && touched.phone ? "error" : ""}
                required
              />
              {errors.phone && touched.phone && (
                <div className="error-message">
                  <FaExclamationTriangle className="error-icon" />
                  {errors.phone}
                </div>
              )}
            </div>
          </div>

          {/* Academic Information */}
          <div className="form-section">
            <h3>
              <FaGraduationCap className="section-icon" /> Academic Information
            </h3>

            <div className="input-group">
              <label htmlFor="course">Course *</label>
              <select
                id="course"
                name="course"
                value={form.course}
                onChange={handleChange}
                className={errors.course && touched.course ? "error" : ""}
                required
              >
                <option value="">Select a course</option>
                <option value="BBA">BBA</option>
                <option value="BCA">BCA</option>
                <option value="BCOM">BCOM</option>
                <option value="B.ED">B.ED</option>
              </select>
              {errors.course && touched.course && (
                <div className="error-message">
                  <FaExclamationTriangle className="error-icon" />
                  {errors.course}
                </div>
              )}
            </div>

            <div className="input-group">
              <label htmlFor="semester">Semester *</label>
              <select
                id="semester"
                name="semester"
                value={form.semester}
                onChange={handleChange}
                className={errors.semester && touched.semester ? "error" : ""}
                required
              >
                <option value="">Select semester</option>
                <option value="SEM-1">SEM-1</option>
                <option value="SEM-2">SEM-2</option>
                <option value="SEM-3">SEM-3</option>
                <option value="SEM-4">SEM-4</option>
                <option value="SEM-5">SEM-5</option>
                <option value="SEM-6">SEM-6</option>
              </select>
              {errors.semester && touched.semester && (
                <div className="error-message">
                  <FaExclamationTriangle className="error-icon" />
                  {errors.semester}
                </div>
              )}
            </div>

            <div className="input-group">
              <label htmlFor="division">Division *</label>
              <input
                type="text"
                id="division"
                name="division"
                placeholder="e.g., A, B, C"
                value={form.division}
                onChange={(e) => {
                  // Only allow a single alphabet character
                  const value = e.target.value
                    .replace(/[^a-zA-Z]/g, "")
                    .slice(0, 1);
                  handleChange({ target: { name: "division", value } });
                }}
                maxLength="1"
                className={errors.division && touched.division ? "error" : ""}
                required
              />
              {errors.division && touched.division && (
                <div className="error-message">
                  <FaExclamationTriangle className="error-icon" />
                  {errors.division}
                </div>
              )}
            </div>

            {!editingId && (
              <div className="input-group">
                <label htmlFor="password">Password *</label>
                <input
                  type="password"
                  id="password"
                  name="password"
                  placeholder="Enter secure password (min 6 characters)"
                  value={form.password}
                  onChange={handleChange}
                  className={errors.password && touched.password ? "error" : ""}
                  required
                />
                {errors.password && touched.password && (
                  <div className="error-message">
                    <FaExclamationTriangle className="error-icon" />
                    {errors.password}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Contact Information */}
          <div className="form-section">
            <h3>
              <FaMapMarkerAlt className="section-icon" /> Contact Information
            </h3>

            <div className="input-group">
              <label htmlFor="address">Address *</label>
              <textarea
                id="address"
                name="address"
                placeholder="Enter complete address"
                value={form.address}
                onChange={handleChange}
                rows="3"
                className={errors.address && touched.address ? "error" : ""}
                required
              />
              {errors.address && touched.address && (
                <div className="error-message">
                  <FaExclamationTriangle className="error-icon" />
                  {errors.address}
                </div>
              )}
            </div>
          </div>

          {/* Subjects Section */}
          <div className="form-section subjects-section">
            <h3>
              <FaBook className="section-icon" /> Subjects & Marks
            </h3>

            {form.subjects.map((subj, idx) => (
              <div key={idx} className="subject-row">
                <div className="input-group">
                  <label>Subject Name</label>
                  <input
                    type="text"
                    placeholder="Enter subject name"
                    value={subj.name}
                    onChange={(e) =>
                      handleSubjectChange(idx, "name", e.target.value)
                    }
                    className={errors[`subject_${idx}_name`] ? "error" : ""}
                    required
                  />
                  {errors[`subject_${idx}_name`] && (
                    <div className="error-message">
                      <FaExclamationTriangle className="error-icon" />
                      {errors[`subject_${idx}_name`]}
                    </div>
                  )}
                </div>
                <div className="input-group">
                  <label>Marks</label>
                  <input
                    type="text" // use text to fully control input
                    placeholder="Enter marks (0-100)"
                    value={subj.marks}
                    onChange={(e) => {
                      const value = e.target.value;
                      // allow only digits
                      if (/^\d*$/.test(value)) {
                        handleSubjectChange(idx, "marks", value);
                      }
                    }}
                    maxLength={3} // prevents more than 3 digits
                    className={errors[`subject_${idx}_marks`] ? "error" : ""}
                  />
                  {errors[`subject_${idx}_marks`] && (
                    <div className="error-message">
                      <FaExclamationTriangle className="error-icon" />
                      {errors[`subject_${idx}_marks`]}
                    </div>
                  )}
                </div>
                <button
                  type="button"
                  className="remove-subject-btn"
                  onClick={() => removeSubject(idx)}
                >
                  <FaMinus />
                </button>
              </div>
            ))}

            <button
              type="button"
              className="add-subject-btn"
              onClick={addSubject}
            >
              <FaPlus /> Add Subject
            </button>
          </div>
        </div>

        <div className="form-buttons">
          <button type="submit" className="submit-btn">
            {editingId ? "Update Student" : "Add Student"}
          </button>
          {editingId && (
            <button
              type="button"
              className="cancel-btn"
              onClick={handleCancelEdit}
            >
              Cancel
            </button>
          )}
        </div>
      </form>
    </div>
  );
}

export default StudentForm;
