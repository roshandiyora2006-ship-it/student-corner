import React, { useState } from "react";
import axios from "axios";
import "./LoginPage.css";


function LoginPage({ setUser }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("student");
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      const res = await axios.post("http://localhost:5000/api/auth/login", {
        email,
        password,
        role,
      });
      localStorage.setItem("token", res.data.token);
      localStorage.setItem("role", res.data.role);
      setUser({ role: res.data.role, token: res.data.token });
    } catch (err) {
      setError(err.response?.data?.error || "Login failed");
    }
  };

  return (
    <div className="login-page-pro">
      <div className="login-left-msg">
        <h1>Welcome to Student-Teacher Portal</h1>
        <p>Manage students, view marks, and empower learning.<br/>Teachers can add students and assign marks.<br/>Students can view their progress anytime.</p>
      </div>
      <div className="login-form-card-pro">
        <h2>Welcome Back</h2>
        <p className="subtitle">Login to your {role.charAt(0).toUpperCase() + role.slice(1)} account</p>
        <div className="role-toggle-pro">
          <button
            className={role === "student" ? "active" : ""}
            onClick={() => setRole("student")}
          >
            Student
          </button>
          <button
            className={role === "teacher" ? "active" : ""}
            onClick={() => setRole("teacher")}
          >
            Teacher
          </button>
        </div>
        <form onSubmit={handleSubmit}>
          <label>Email</label>
          <input
            type="email"
            placeholder="Enter your email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            required
            autoFocus
          />
          <label>Password</label>
          <input
            type="password"
            placeholder="Enter your password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            required
          />
          <div className="login-row">
            <label className="remember-me">
              <input type="checkbox" /> Remember me
            </label>
            <a href="#" className="forgot-link">Forgot Password?</a>
          </div>
          {error && <div className="error-msg">{error}</div>}
          <button type="submit" className="login-btn-pro">Login</button>
        </form>
        <div className="signup-row">
          Don’t have an account? <a href="#" className="signup-link">Sign up</a>
        </div>
      </div>
    </div>
  );
}

export default LoginPage;
