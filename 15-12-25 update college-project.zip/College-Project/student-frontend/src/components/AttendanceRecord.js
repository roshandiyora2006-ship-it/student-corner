import React, { useState, useEffect } from "react";
import axios from "axios";
import "./AttendanceRecord.css";

function AttendanceRecord() {
  const [attendanceRecords, setAttendanceRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [summary, setSummary] = useState(null);
  const token = localStorage.getItem("token");

  // Fetch student's own attendance
  const fetchMyAttendance = async () => {
    try {
      setLoading(true);
      setError("");
      
      if (!token) {
        setError("No authentication token found. Please login again.");
        setLoading(false);
        return;
      }

      const res = await axios.get("http://localhost:5000/api/attendance/me", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setAttendanceRecords(res.data);

      // Calculate summary
      const total = res.data.length;
      const present = res.data.filter((r) => r.status === "Present").length;
      const absent = res.data.filter((r) => r.status === "Absent").length;
      const leave = res.data.filter((r) => r.status === "Leave").length;

      setSummary({
        total,
        present,
        absent,
        leave,
        percentage: total > 0 ? ((present / total) * 100).toFixed(2) : 0,
      });
    } catch (err) {
      console.error("Error fetching attendance:", err);
      setError(err.response?.data?.message || err.response?.data?.error || "Failed to fetch attendance records. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMyAttendance();
  }, [token]);

  if (loading) {
    return <div className="loading">Loading attendance records...</div>;
  }

  return (
    <div className="attendance-record-container">
      <h2>Your Attendance</h2>

      {error && <div className="error-message">{error}</div>}

      {summary && (
        <div className="attendance-summary">
          <div className="summary-card total">
            <h4>Total Classes</h4>
            <p className="summary-value">{summary.total}</p>
          </div>
          <div className="summary-card present">
            <h4>Present</h4>
            <p className="summary-value">{summary.present}</p>
          </div>
          <div className="summary-card absent">
            <h4>Absent</h4>
            <p className="summary-value">{summary.absent}</p>
          </div>
          <div className="summary-card leave">
            <h4>Leave</h4>
            <p className="summary-value">{summary.leave}</p>
          </div>
          <div className="summary-card percentage">
            <h4>Attendance %</h4>
            <p className="summary-value">{summary.percentage}%</p>
          </div>
        </div>
      )}

      {attendanceRecords.length > 0 ? (
        <div className="attendance-table-wrapper">
          <table className="attendance-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Subject</th>
                <th>Status</th>
                <th>Remarks</th>
                <th>Marked By</th>
              </tr>
            </thead>
            <tbody>
              {attendanceRecords.map((record) => (
                <tr key={record._id} className={`status-${record.status.toLowerCase()}`}>
                  <td>{new Date(record.date).toLocaleDateString()}</td>
                  <td>{record.subject}</td>
                  <td>
                    <span className={`status-badge status-${record.status.toLowerCase()}`}>
                      {record.status}
                    </span>
                  </td>
                  <td>{record.remarks || "—"}</td>
                  <td>{record.markedBy?.name || "N/A"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="no-records">
          <p>No attendance records found.</p>
        </div>
      )}
    </div>
  );
}

export default AttendanceRecord;
