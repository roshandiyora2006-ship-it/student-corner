
/*
import React, { useState, useEffect } from "react";
import axios from "axios";
import "./StudentFeesView.css";

function StudentFeesView() {
  const [fees, setFees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [totalDue, setTotalDue] = useState(0);
  const [paymentModal, setPaymentModal] = useState(false);
  const [selectedFee, setSelectedFee] = useState(null);
  const [paymentData, setPaymentData] = useState({
    amount: "",
  });
  const [message, setMessage] = useState("");
  const [messageType, setMessageType] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [stripe, setStripe] = useState(null);
  const [elements, setElements] = useState(null);
  const [paymentElement, setPaymentElement] = useState(null);
  const token = localStorage.getItem("token");

  // Initialize Stripe with Payment Element
  useEffect(() => {
    if (window.Stripe) {
      const stripeInstance = window.Stripe("pk_test_51SdSvNPF19en5zSD3lNQULPn4r4OMNoq0aobIfuyg3EgKjcEvGFgUnNImhr21GU4Ac4nMaQC4ghrQW45TUrPSz9k00q3sHxK0m");
      setStripe(stripeInstance);
      
      // Create elements instance
      const elementsInstance = stripeInstance.elements();
      setElements(elementsInstance);
    }
  }, []);

  useEffect(() => {
    const fetchFees = async () => {
      try {
        setLoading(true);
        const res = await axios.get("http://localhost:5000/api/fees/me", {
          headers: { Authorization: `Bearer ${token}` },
        });

        console.log("Fees data received:", res.data);
        let feesArray = Array.isArray(res.data) ? res.data : res.data.fees || [];
        
        // Get latest fees for each course-semester combination
        const latestFees = {};
        feesArray.forEach((fee) => {
          const key = `${fee.course}-${fee.semester}`;
          if (!latestFees[key] || new Date(fee.createdAt) > new Date(latestFees[key].createdAt)) {
            latestFees[key] = fee;
          }
        });
        
        feesArray = Object.values(latestFees).sort((a, b) => 
          new Date(b.createdAt) - new Date(a.createdAt)
        );
        
        setFees(feesArray);

        // Calculate total amount due (not paid)
        const total = feesArray.reduce((sum, fee) => sum + (fee.amount - fee.paidAmount), 0);
        setTotalDue(total);
      } catch (error) {
        console.error("Error fetching fees:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchFees();
  }, [token]);

  const openPaymentModal = (fee) => {
    setSelectedFee(fee);
    setPaymentData({
      amount: fee.amount - fee.paidAmount,
    });
    setPaymentModal(true);
    
    // Create and mount payment element when modal opens
    setTimeout(() => {
      if (elements && !paymentElement) {
        const paymentEl = elements.create("payment");
        setPaymentElement(paymentEl);
        paymentEl.mount("#payment-element");
        console.log("✅ Payment element mounted (supports Card, Google Pay, Apple Pay)");
      } else if (paymentElement) {
        paymentElement.mount("#payment-element");
      }
    }, 100);
  };

  const closePaymentModal = () => {
    // Unmount payment element
    if (paymentElement) {
      try {
        paymentElement.unmount();
        setPaymentElement(null);
        console.log("✅ Payment element unmounted");
      } catch (e) {
        console.log("Payment element already unmounted");
      }
    }
    
    setPaymentModal(false);
    setSelectedFee(null);
    setPaymentData({ amount: "" });
    setMessage("");
  };

  const handlePaymentSubmit = async (e) => {
    e.preventDefault();
    if (!paymentData.amount || paymentData.amount <= 0) {
      setMessage("Please enter a valid amount");
      setMessageType("error");
      return;
    }

    if (!stripe || !elements) {
      setMessage("Payment system not ready. Please refresh the page.");
      setMessageType("error");
      return;
    }

    setIsProcessing(true);
    setMessage("");

    try {
      console.log("🚀 Starting Stripe payment with Payment Element...");
      const amount = parseFloat(paymentData.amount);
      console.log("Amount to pay:", amount);
      console.log("Fee ID:", selectedFee._id);

      // Step 1: Create Payment Intent
      console.log("📦 Creating payment intent on backend...");
      const intentResponse = await axios.post(
        "http://localhost:5000/api/stripe/create-payment-intent",
        {
          amount: amount,
          feesId: selectedFee._id,
          description: `Payment for ${selectedFee.course} - Semester ${selectedFee.semester}`,
        },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      console.log("✅ Payment intent response:", intentResponse.data);
      const { clientSecret } = intentResponse.data;
      
      if (!clientSecret) {
        throw new Error("No client secret returned from server");
      }

      // Step 2: Confirm Payment using Payment Element (supports Card, Google Pay, Apple Pay, etc.)
      console.log("💳 Confirming payment with Payment Element...");
      const { error, paymentIntent } = await stripe.confirmPayment({
        elements,
        clientSecret,
        confirmParams: {
          return_url: `${window.location.origin}/fees`,
        },
      });

      if (error) {
        console.error("❌ Payment error:", error.message);
        setMessage(`Payment failed: ${error.message}`);
        setMessageType("error");
        setIsProcessing(false);
        return;
      }

      console.log("💳 Payment intent status:", paymentIntent.status);
      console.log("💳 Payment intent ID:", paymentIntent.id);

      if (paymentIntent.status === "succeeded") {
        console.log("✅ Payment succeeded on Stripe side!");

        // Step 3: Confirm Payment on Backend
        console.log("📞 Notifying backend of successful payment...");
        const confirmResponse = await axios.post(
          "http://localhost:5000/api/stripe/confirm-payment",
          {
            paymentIntentId: paymentIntent.id,
            feesId: selectedFee._id,
            amount: amount,
          },
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );

        console.log("✅ Backend confirmed payment:", confirmResponse.data);
        setMessage("✅ Payment successful! Fees updated.");
        setMessageType("success");

        // Update fees list
        const updatedFees = fees.map((fee) =>
          fee._id === selectedFee._id ? confirmResponse.data.fees : fee
        );
        setFees(updatedFees);

        // Recalculate total due
        const newTotal = updatedFees.reduce(
          (sum, fee) => sum + (fee.amount - fee.paidAmount),
          0
        );
        setTotalDue(newTotal);

        setTimeout(() => closePaymentModal(), 2000);
      } else if (paymentIntent.status === "processing") {
        console.log("⏳ Payment is still processing...");
        setMessage("Payment is processing. Please wait...");
        setMessageType("error");
      } else if (paymentIntent.status === "requires_payment_method") {
        console.log("❌ Payment requires a different payment method");
        setMessage("Payment method not accepted. Please try another method.");
        setMessageType("error");
      } else {
        console.log("❌ Unexpected payment intent status:", paymentIntent.status);
        setMessage(`Payment status: ${paymentIntent.status}`);
        setMessageType("error");
      }
    } catch (error) {
      console.error("❌ Payment error:", error);
      const errorMessage = 
        error.response?.data?.message ||
        error.response?.data?.error ||
        error.message ||
        "Payment failed";
      
      console.error("Error message to show:", errorMessage);
      setMessage(errorMessage);
      setMessageType("error");
    } finally {
      setIsProcessing(false);
    }
  };

  if (loading) {
    return <div className="loading">Loading fees information...</div>;
  }

  return (
    <div className="student-fees-view">
      
      <div className="amount-due-section">
        <div className="amount-due-card">
          <div className="amount-label">Total Amount Due</div>
          <div className="amount-value">₹{totalDue.toLocaleString()}</div>
          {totalDue > 0 && (
            <button
              className="btn-pay"
              onClick={() => {
                if (fees.length > 0) {
                  openPaymentModal(fees[0]);
                } else {
                  alert("No fees found");
                }
              }}
            >
              Pay Fees
            </button>
          )}
          {totalDue === 0 && (
            <div className="paid-status">✅ All fees paid</div>
          )}
        </div>
      </div>

   
      {paymentModal && selectedFee && (
        <div className="modal-overlay" onClick={closePaymentModal}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Pay Fees with Stripe</h3>
              <button 
                className="btn-close" 
                onClick={closePaymentModal}
                disabled={isProcessing}
              >
                ✕
              </button>
            </div>

            <div className="modal-body">
              {message && (
                <div className={`alert alert-${messageType}`}>
                  {message}
                </div>
              )}

              <div className="payment-info">
                <div className="info-row">
                  <span className="info-label">Course:</span>
                  <span className="info-value">{selectedFee.course}</span>
                </div>
                <div className="info-row">
                  <span className="info-label">Semester:</span>
                  <span className="info-value">{selectedFee.semester}</span>
                </div>
                <div className="info-row">
                  <span className="info-label">Total Amount:</span>
                  <span className="info-value">₹{selectedFee.amount.toLocaleString()}</span>
                </div>
                <div className="info-row">
                  <span className="info-label">Already Paid:</span>
                  <span className="info-value paid">₹{selectedFee.paidAmount.toLocaleString()}</span>
                </div>
                <div className="info-row">
                  <span className="info-label">Total Due:</span>
                  <span className="info-value pending">
                    ₹{(selectedFee.amount - selectedFee.paidAmount).toLocaleString()}
                  </span>
                </div>
              </div>

              <form onSubmit={handlePaymentSubmit} className="payment-form">
                <div className="form-group">
                  <label>Payment Amount (₹)</label>
                  <input
                    type="number"
                    value={paymentData.amount}
                    onChange={(e) =>
                      setPaymentData((prev) => ({
                        ...prev,
                        amount: e.target.value,
                      }))
                    }
                    min="0"
                    step="100"
                    max={selectedFee.amount - selectedFee.paidAmount}
                    required
                    disabled={isProcessing}
                  />
                </div>

                <div className="form-group">
                  <label>Payment Method</label>
                  <div id="payment-element" className="stripe-payment-element"></div>
                </div>

                <div className="stripe-info">
                  <p>🔒 Secure payment powered by Stripe</p>
                  <p style={{ fontSize: "12px", marginTop: "8px" }}>
                    Supports: Card, Google Pay, Apple Pay & more
                  </p>
                </div>

                <div className="modal-actions">
                  <button
                    type="button"
                    className="btn-cancel"
                    onClick={closePaymentModal}
                    disabled={isProcessing}
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit" 
                    className="btn-submit"
                    disabled={isProcessing}
                  >
                    {isProcessing ? "Processing..." : "Pay with Stripe"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default StudentFeesView;
*/


import React, { useEffect, useState } from "react";
import axios from "axios";
import { loadStripe } from "@stripe/stripe-js";
import {
  Elements,
  PaymentElement,
  useStripe,
  useElements,
} from "@stripe/react-stripe-js";
import jsPDF from "jspdf";
import "./StudentFeesView.css";

const stripePromise = loadStripe(
  "pk_test_51SdSvNPF19en5zSD3lNQULPn4r4OMNoq0aobIfuyg3EgKjcEvGFgUnNImhr21GU4Ac4nMaQC4ghrQW45TUrPSz9k00q3sHxK0m"
);

function StudentFeesView() {
  const token = localStorage.getItem("token");

  const [fees, setFees] = useState([]);
  const [totalDue, setTotalDue] = useState(0);
  const [loading, setLoading] = useState(true);

  const [selectedFee, setSelectedFee] = useState(null);
  const [clientSecret, setClientSecret] = useState(null);
  const [paymentModal, setPaymentModal] = useState(false);

  const [message, setMessage] = useState("");
  const [messageType, setMessageType] = useState("");

  // ================= FETCH FEES =================
  const fetchFees = async () => {
    try {
      setLoading(true);
      const res = await axios.get(
        "http://localhost:5000/api/fees/me",
        { headers: { Authorization: `Bearer ${token}` } }
      );

      const feesArray = Array.isArray(res.data)
        ? res.data
        : res.data.fees || [];

      setFees(feesArray);

      const due = feesArray.reduce(
        (sum, f) => sum + (f.amount - f.paidAmount),
        0
      );
      setTotalDue(due);
    } catch (err) {
      console.error("Fetch fees error", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFees();
  }, []);

  // ================= OPEN PAYMENT =================
  const openPaymentModal = async (fee) => {
    setSelectedFee(fee);
    setPaymentModal(true);
    setMessage("");

    try {
      const res = await axios.post(
        "http://localhost:5000/api/stripe/create-payment-intent",
        {
          amount: fee.amount - fee.paidAmount,
          feesId: fee._id,
        },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      setClientSecret(res.data.clientSecret);
    } catch (err) {
      console.error(err);
      setMessage("Unable to start payment");
      setMessageType("error");
    }
  };

  const closePaymentModal = () => {
    setPaymentModal(false);
    setClientSecret(null);
    setSelectedFee(null);
  };

  // ================= RECEIPT PDF =================

  const downloadReceipt = (fee) => {
    const makePdf = (imgData) => {
      const doc = new jsPDF({ unit: "pt", format: "a4" });
      const pageWidth = doc.internal.pageSize.getWidth();

      // Header: try to use logo if available
      if (imgData) {
        try {
          doc.addImage(imgData, "PNG", 40, 12, 60, 60);
        } catch (e) {
          console.warn("Failed to add logo to PDF:", e);
        }
        doc.setFontSize(20);
        doc.setTextColor(34, 34, 34);
        doc.setFont("helvetica", "bold");
        doc.text("Student Corner", 110, 38);
        doc.setFontSize(10);
        doc.setFont("helvetica", "normal");
        doc.text("Jahangirpura, Surat - 935401", 110, 54);
      } else {
        // Fallback header bar
        doc.setFillColor(102, 126, 234);
        doc.rect(0, 0, pageWidth, 60, "F");
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(20);
        doc.setFont("helvetica", "bold");
        doc.text("Student Corner", 40, 38);
        doc.setFontSize(10);
        doc.setFont("helvetica", "normal");
        doc.text("Jahangirpura, Surat - 935401", 40, 54);
      }

      // Title on right
      doc.setTextColor(34, 34, 34);
      doc.setFontSize(16);
      doc.setFont("helvetica", "bold");
      doc.text("Fee Payment Receipt", pageWidth - 220, 38);

      // Transaction box
      const startY = 90;
      doc.setDrawColor(200);
      doc.setFillColor(245, 245, 245);
      doc.roundedRect(36, startY - 10, pageWidth - 72, 70, 6, 6, "F");

      doc.setFontSize(11);
      doc.setTextColor(70, 70, 70);
      doc.text(`Transaction ID: ${fee.transactionId || "-"}`, 50, startY + 6);
      doc.text(
        `Date: ${fee.updatedAt ? new Date(fee.updatedAt).toLocaleString() : "-"}`,
        50,
        startY + 26
      );
      doc.text(`Payment Method: ${fee.paymentMethod || "Stripe"}`, 50, startY + 46);

      // Receipt table header
      const tableY = startY + 100;
      const colX = [50, pageWidth - 200, pageWidth - 110];

      doc.setFont("helvetica", "bold");
      doc.setFontSize(12);
      doc.text("Description", colX[0], tableY);
      doc.text("Amount (₹)", colX[1], tableY);
      doc.text("Status", colX[2], tableY);

      doc.setDrawColor(220);
      doc.line(46, tableY + 6, pageWidth - 46, tableY + 6);

      // Row with fee details
      doc.setFont("helvetica", "normal");
      doc.setFontSize(11);
      const rowY = tableY + 28;
      const description = `${fee.course} - Semester ${fee.semester}`;
      doc.text(description, colX[0], rowY);

      const amountStr = `₹${(fee.paidAmount || 0).toLocaleString()}`;
      doc.text(amountStr, colX[1], rowY);

      const statusStr = fee.status || (fee.paidAmount >= fee.amount ? "Paid" : "Partial");
      doc.text(statusStr, colX[2], rowY);

      // Totals box
      const totalsY = rowY + 36;
      doc.setFontSize(11);
      doc.text("Total Amount:", colX[1] - 80, totalsY);
      doc.setFont("helvetica", "bold");
      doc.text(`₹${(fee.amount || 0).toLocaleString()}`, colX[1], totalsY);

      doc.setFont("helvetica", "normal");

      // Footer note
      const footerY = 780;
      doc.setDrawColor(230);
      doc.line(36, footerY - 20, pageWidth - 36, footerY - 20);
      doc.setFontSize(10);
      doc.text(
        "This is a system generated receipt. For queries contact accounts@studentcorner.edu",
        40,
        footerY
      );

      // Save PDF
      const filename = `Fee_Receipt_${fee.transactionId || Date.now()}.pdf`;
      doc.save(filename);
    };

    // Try load logo from public folder (/logo.png). If not present, fallback to styled header.
    try {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.src = "/logo.png";
      img.onload = () => {
        try {
          const canvas = document.createElement("canvas");
          canvas.width = img.width;
          canvas.height = img.height;
          const ctx = canvas.getContext("2d");
          ctx.drawImage(img, 0, 0);
          const imgData = canvas.toDataURL("image/png");
          makePdf(imgData);
        } catch (e) {
          console.warn("Could not convert logo to DataURL, generating PDF without logo", e);
          makePdf(null);
        }
      };
      img.onerror = () => {
        makePdf(null);
      };
    } catch (e) {
      console.warn("Logo load failed, generating PDF without logo", e);
      makePdf(null);
    }
  };

  const unpaidFee = fees.find(
    (f) => f.amount > f.paidAmount
  );



  if (loading) return <div className="loading">Loading...</div>;

  return (
    <div className="student-fees-view">
      {/* ===== TOTAL DUE ===== */}
      <div className="amount-due-card">
        <h3>Total Amount Due</h3>
        <h2>₹{totalDue.toLocaleString()}</h2>

        {unpaidFee ? (
          <button
            className="btn-pay"
            onClick={() => openPaymentModal(unpaidFee)}
          >
            Pay Fees
          </button>
        ) : (
          <div className="paid-status">✅ All fees paid</div>
        )}
      </div>

      {/* ===== FEES TABLE ===== */}
      {fees.length > 0 && (
        <div className="fees-table">
          <h3>My Fees</h3>
          <table>
            <thead>
              <tr>
                <th>Course</th>
                <th>Semester</th>
                <th>Total</th>
                <th>Paid</th>
                <th>Due</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {fees.map((fee) => {
                const due = fee.amount - fee.paidAmount;
                return (
                  <tr key={fee._id}>
                    <td>{fee.course}</td>
                    <td>{fee.semester}</td>
                    <td>₹{fee.amount}</td>
                    <td>₹{fee.paidAmount}</td>
                    <td>₹{due}</td>
                    <td className={due === 0 ? "success" : "pending"}>
                      {due === 0 ? "Paid" : "Pending"}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* ===== PAYMENT HISTORY (FROM FEES) ===== */}
      {fees.some((f) => f.status === "Paid") && (
        <div className="payment-history">
          <h3>Payment History</h3>
          <table className="history-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Course</th>
                <th>Semester</th>
                <th>Amount Paid</th>
                <th>Method</th>
                <th>Transaction</th>
                <th>Receipt</th>
              </tr>
            </thead>
            <tbody>
              {fees
                .filter((f) => f.status === "Paid")
                .map((fee) => (
                  <tr key={fee._id}>
                    <td>
                      {new Date(fee.updatedAt).toLocaleDateString()}
                    </td>
                    <td>{fee.course}</td>
                    <td>{fee.semester}</td>
                    <td>₹{fee.paidAmount}</td>
                    <td>{fee.paymentMethod}</td>
                    <td>{fee.transactionId}</td>
                    <td>
                      <button
                        className="btn-receipt"
                        onClick={() => downloadReceipt(fee)}
                      >
                        Download PDF
                      </button>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      )}

      {/* ===== PAYMENT MODAL ===== */}
      {paymentModal && clientSecret && (
        <div className="modal-overlay">
          <div className="modal-content">
            <button className="btn-close" onClick={closePaymentModal}>
              ✕
            </button>

            {message && (
              <div className={`alert ${messageType}`}>
                {message}
              </div>
            )}

            <Elements stripe={stripePromise} options={{ clientSecret }}>
              <CheckoutForm
                closeModal={closePaymentModal}
                refreshFees={fetchFees}
              />
            </Elements>
          </div>
        </div>
      )}
    </div>
  );
}

// ================= CHECKOUT FORM =================
function CheckoutForm({ closeModal, refreshFees }) {
  const stripe = useStripe();
  const elements = useElements();
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!stripe || !elements) return;

    setProcessing(true);

    const { error } = await stripe.confirmPayment({
      elements,
      redirect: "if_required",
    });

    if (error) {
      setError(error.message);
      setProcessing(false);
    } else {
      await refreshFees();
      closeModal();
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <PaymentElement />
      {error && <div className="error">{error}</div>}
      <button disabled={processing} className="btn-submit">
        {processing ? "Processing..." : "Pay Now"}
      </button>
    </form>
  );
}

export default StudentFeesView;






