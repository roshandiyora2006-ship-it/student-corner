import React from "react";

function About() {
  return (
    <div style={{ padding: "20px" }}>
      <h1>About This Project</h1>
      <p>This Student Management System is built with React + Node.js + MongoDB.</p>
      <p>You can Add, Edit, Delete, and View student details easily.</p>
    </div>
  );
}

export default About;

