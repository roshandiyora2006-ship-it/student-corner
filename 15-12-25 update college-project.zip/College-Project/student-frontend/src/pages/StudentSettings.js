import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { FaEdit, FaTimes, FaCheck } from 'react-icons/fa';
import './StudentSettings.css';

export default function StudentSettings() {
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    dob: '',
    semester: '',
    division: '',
    course: '',
    password: ''
  });
  const [original, setOriginal] = useState({ ...form });
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('');

  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/students/me', {
          headers: { Authorization: `Bearer ${token}` }
        });
        const data = res.data || {};
        const profileData = {
          name: data.name || '',
          email: data.email || '',
          phone: data.phone || '',
          address: data.address || '',
          dob: data.dob ? data.dob.split('T')[0] : '',
          semester: data.semester || '',
          division: data.division || '',
          course: data.course || '',
          password: ''
        };
        setForm(profileData);
        setOriginal(profileData);
      } catch (err) {
        console.error(err);
        setMessage('Failed to load profile');
        setMessageType('error');
      } finally {
        setLoading(false);
      }
    };
    fetchProfile();
  }, [token]);

  const handleEdit = () => {
    setIsEditing(true);
    setMessage('');
  };

  const handleCancel = () => {
    setForm({ ...original });
    setIsEditing(false);
    setMessage('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('');
    try {
      const payload = {
        name: form.name,
        email: form.email,
        phone: form.phone,
        address: form.address,
        dob: form.dob
      };
      // do not send empty password
      if (form.password && form.password.trim()) {
        payload.password = form.password;
      }
      const res = await axios.put('http://localhost:5000/api/students/me', payload, {
        headers: { Authorization: `Bearer ${token}` }
      });
      // Update original with new data
      const newData = {
        name: res.data.name || '',
        email: res.data.email || '',
        phone: res.data.phone || '',
        address: res.data.address || '',
        dob: res.data.dob ? res.data.dob.split('T')[0] : '',
        semester: res.data.semester || '',
        division: res.data.division || '',
        course: res.data.course || '',
        password: ''
      };
      setOriginal(newData);
      setForm(newData);
      setMessage('Profile updated successfully ✓');
      setMessageType('success');
      setIsEditing(false);
    } catch (err) {
      setMessage(err.response?.data?.message || 'Failed to update profile');
      setMessageType('error');
    }
  };

  if (loading) {
    return (
      <div className="settings-page">
        <div className="loading-spinner">Loading...</div>
      </div>
    );
  }

  return (
    <div className="settings-page">
      <div className="settings-header">
        <h1>My Profile Settings</h1>
        <p className="subtitle">Manage your personal information</p>
      </div>

      {message && (
        <div className={`alert alert-${messageType}`}>
          {message}
        </div>
      )}

      <div className="settings-container">
        {!isEditing ? (
          // View Mode
          <div className="profile-card">
            <div className="profile-header">
              <div className="profile-avatar">
                {form.name ? form.name.split(' ').map((n) => n[0]).slice(0, 2).join('').toUpperCase() : '?'}
              </div>
              <div className="profile-info">
                <h2>{form.name}</h2>
                <p>{form.email}</p>
              </div>
              <button className="edit-button" onClick={handleEdit}>
                <FaEdit /> Edit Profile
              </button>
            </div>

            <div className="profile-grid">
              <div className="profile-item">
                <label>Phone</label>
                <p>{form.phone || 'Not provided'}</p>
              </div>
              <div className="profile-item">
                <label>Address</label>
                <p>{form.address || 'Not provided'}</p>
              </div>
              <div className="profile-item">
                <label>Date of Birth</label>
                <p>{form.dob || 'Not provided'}</p>
              </div>
              <div className="profile-item">
                <label>Course</label>
                <p>{form.course || 'Not provided'}</p>
              </div>
              <div className="profile-item">
                <label>Semester</label>
                <p>{form.semester || 'Not provided'}</p>
              </div>
              <div className="profile-item">
                <label>Division</label>
                <p>{form.division || 'Not provided'}</p>
              </div>
            </div>
          </div>
        ) : (
          // Edit Mode
          <form className="edit-form" onSubmit={handleSubmit}>
            <div className="edit-header">
              <h2>Edit Personal Information</h2>
              <p>Update your profile details below</p>
            </div>

            <div className="form-grid">
              <div className="form-group">
                <label>Name *</label>
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="Your full name"
                  required
                />
              </div>

              <div className="form-group">
                <label>Email *</label>
                <input
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="your@email.com"
                  required
                />
              </div>

              <div className="form-group">
                <label>Phone</label>
                <input
                  type="tel"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  placeholder="10-digit phone number"
                />
              </div>

              <div className="form-group">
                <label>Address</label>
                <input
                  type="text"
                  value={form.address}
                  onChange={(e) => setForm({ ...form, address: e.target.value })}
                  placeholder="Your address"
                />
              </div>

              <div className="form-group">
                <label>Date of Birth</label>
                <input
                  type="date"
                  value={form.dob}
                  onChange={(e) => setForm({ ...form, dob: e.target.value })}
                />
              </div>

              <div className="form-group full-width">
                <label>New Password (leave blank to keep current)</label>
                <input
                  type="password"
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  placeholder="Enter new password to change"
                />
              </div>
            </div>

            <div className="form-actions">
              <button type="submit" className="btn-save">
                <FaCheck /> Save Changes
              </button>
              <button type="button" className="btn-cancel" onClick={handleCancel}>
                <FaTimes /> Cancel
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
