import React from "react";
import AttendanceForm from "../components/AttendanceForm";
import AttendanceRecord from "../components/AttendanceRecord";
import TeacherAttendanceView from "../components/TeacherAttendanceView";
import AttendanceReport from "../components/AttendanceReport";
import "./Attendance.css";

function Attendance() {
  const userRole = localStorage.getItem("role");

  return (
    <div className="attendance-page">
      {userRole === "teacher" ? (
        <div className="teacher-view">
          <h1>Attendance Management</h1>
          <div className="teacher-sections">
            <section className="attendance-section">
              <h2>Mark Attendance</h2>
              <AttendanceForm />
            </section>
            <section className="attendance-section">
              <TeacherAttendanceView />
            </section>
            <section className="attendance-section">
              <AttendanceReport />
            </section>
          </div>
        </div>
      ) : (
        <div className="student-view">
          <h1>My Attendance Record</h1>
          <AttendanceRecord />
        </div>
      )}
    </div>
  );
}

export default Attendance;
